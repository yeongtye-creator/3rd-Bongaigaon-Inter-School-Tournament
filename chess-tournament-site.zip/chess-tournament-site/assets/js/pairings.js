/**
 * pairings.js
 * -----------------------------------------------------------------------
 * Drives pairings.html: loads the list of published rounds, lets the user
 * pick a round, renders pairing cards, supports search-by-player and
 * auto-refreshes the current round every REFRESH_INTERVAL_MS.
 * -----------------------------------------------------------------------
 */
(function () {
  "use strict";

  const state = {
    rounds: [],
    currentRound: null,
    items: [],
    query: "",
  };
  const els = {};

  document.addEventListener("DOMContentLoaded", async () => {
    els.roundSelector = document.getElementById("round-selector");
    els.grid = document.getElementById("pairings-grid");
    els.title = document.getElementById("pairings-title");
    els.search = document.getElementById("pairings-search");
    els.count = document.getElementById("pairings-count");
    els.demoBanner = document.getElementById("demo-banner");

    els.search.addEventListener(
      "input",
      Utils.debounce((e) => {
        state.query = e.target.value.trim().toLowerCase();
        render();
      }, 180)
    );

    await loadRounds();
    const indicator = UI.refreshIndicator(CONFIG.REFRESH_INTERVAL_MS, () => loadPairings(state.currentRound));
    indicator.start();
  });

  async function loadRounds() {
    els.roundSelector.innerHTML = `<div class="skeleton" style="width:280px;height:38px;border-radius:999px"></div>`;
    try {
      const [torneoRes, roundsRes] = await Promise.all([Api.getTournament(), Api.getRounds()]);
      if (els.title && torneoRes.data.nome) els.title.textContent = torneoRes.data.nome;
      state.rounds = (roundsRes.data.items || []).map((r) => Number(r.turno)).sort((a, b) => a - b);
      if (!state.rounds.length && torneoRes.data.num_turni) {
        const upTo = torneoRes.data.turno_corrente || torneoRes.data.num_turni;
        state.rounds = Array.from({ length: upTo }, (_, i) => i + 1);
      }
      const initialRound = state.rounds.length ? state.rounds[state.rounds.length - 1] : 1;
      renderRoundSelector(initialRound);
      await loadPairings(initialRound);
    } catch (err) {
      UI.errorState(els.grid, err.message, loadRounds);
    }
  }

  function renderRoundSelector(active) {
    state.currentRound = active;
    if (!state.rounds.length) state.rounds = [1];
    els.roundSelector.innerHTML = state.rounds
      .map(
        (r) =>
          `<button class="round-pill ${r === active ? "is-active" : ""}" data-round="${r}">Round ${r}</button>`
      )
      .join("");
    Utils.qsa("[data-round]", els.roundSelector).forEach((btn) =>
      btn.addEventListener("click", () => {
        const r = Number(btn.dataset.round);
        Utils.qsa(".round-pill", els.roundSelector).forEach((b) => b.classList.remove("is-active"));
        btn.classList.add("is-active");
        state.currentRound = r;
        loadPairings(r);
      })
    );
  }

  async function loadPairings(round) {
    els.grid.innerHTML = UI.skeletonCards(6);
    try {
      const res = await Api.getPairings(round);
      if (els.demoBanner) els.demoBanner.style.display = res.isDemo ? "flex" : "none";
      state.items = res.data.items || [];
      if (res.data.turno) state.currentRound = res.data.turno;
      render();
    } catch (err) {
      UI.errorState(els.grid, err.message, () => loadPairings(round));
    }
  }

  function render() {
    if (!state.items.length) {
      UI.emptyState(els.grid, "No pairings for this round yet", "Pairings will appear here as soon as they are published.");
      els.count.textContent = "";
      return;
    }
    let rows = state.items;
    if (state.query) {
      rows = rows.filter((row) => {
        const w = row.bianco ? Utils.fullName(row.bianco).toLowerCase() : "";
        const b = row.nero ? Utils.fullName(row.nero).toLowerCase() : "";
        return w.includes(state.query) || b.includes(state.query);
      });
    }
    if (!rows.length) {
      UI.emptyState(els.grid, "No matches", "No players on this board match your search.");
      els.count.textContent = "0 results";
      return;
    }
    els.count.textContent = `${rows.length} board${rows.length === 1 ? "" : "s"} · Round ${state.currentRound}`;
    els.grid.innerHTML = rows.map(cardHtml).join("");
  }

  function cardHtml(row) {
    const isBye = !row.nero || row.tipo === "bye";
    const result = isBye ? "Bye" : Utils.resultLabel(row.risultato);
    const decided = !isBye && row.risultato;
    return `
      <div class="pairing-card fade-in ${isBye ? "is-bye" : ""}">
        <div class="pairing-head">
          <span class="board-no">Board ${Utils.escapeHtml(row.tavolo ?? "-")}</span>
          <span class="result-pill ${decided ? "is-decided" : ""}">${Utils.escapeHtml(result)}</span>
        </div>
        <div class="pairing-players">
          <div class="pairing-side">
            <div class="pairing-player">
              <span class="side-swatch white" aria-hidden="true"></span>
              <span class="pairing-player-name">${row.bianco?.titolo ? `<span class="title-tag">${Utils.escapeHtml(row.bianco.titolo)}</span> ` : ""}${Utils.escapeHtml(row.bianco ? Utils.fullName(row.bianco) : "TBD")}</span>
            </div>
            <span class="pairing-player-rtg">${Utils.escapeHtml(row.bianco?.rating ?? "—")}</span>
          </div>
          <div class="pairing-vs-divider"></div>
          <div class="pairing-side">
            <div class="pairing-player">
              <span class="side-swatch black" aria-hidden="true"></span>
              <span class="pairing-player-name">${row.nero?.titolo ? `<span class="title-tag">${Utils.escapeHtml(row.nero.titolo)}</span> ` : ""}${isBye ? "— (bye)" : Utils.escapeHtml(Utils.fullName(row.nero))}</span>
            </div>
            <span class="pairing-player-rtg">${isBye ? "" : Utils.escapeHtml(row.nero?.rating ?? "—")}</span>
          </div>
        </div>
      </div>`;
  }
})();
