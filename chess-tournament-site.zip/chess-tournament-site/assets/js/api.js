/**
 * api.js
 * -----------------------------------------------------------------------
 * Thin wrapper around the ChessPairings REST API (v1).
 * Every network call in the site goes through this module — nothing else
 * should call fetch() directly against the API. This keeps the API easy
 * to swap out or mock later.
 *
 * Endpoints used (see ChessPairings API v1 docs):
 *   GET /torneo/{id}                          tournament info
 *   GET /torneo/{id}/classifica                standings
 *   GET /torneo/{id}/abbinamenti?turno=N        pairings for round N
 *   GET /torneo/{id}/turni                      list of published rounds
 *   GET /torneo/{id}/iscritti?ordinamento=X     enrolled players
 *   GET /torneo/{id}/bando                      rules / announcement doc
 * -----------------------------------------------------------------------
 */
(function (global) {
  "use strict";

  const CONFIG = global.CONFIG;
  const memoryCache = new Map(); // key -> { data, expires }

  /** Build a full URL with query params against the configured base. */
  function buildUrl(path, params) {
    const url = new URL(
      CONFIG.API_BASE_URL.replace(/\/$/, "") + "/" + path.replace(/^\//, "")
    );
    if (params) {
      Object.keys(params).forEach((k) => {
        if (params[k] !== undefined && params[k] !== null && params[k] !== "") {
          url.searchParams.set(k, params[k]);
        }
      });
    }
    return url.toString();
  }

  /** Custom error carrying an HTTP-style code + friendly message. */
  class ApiError extends Error {
    constructor(message, code) {
      super(message);
      this.name = "ApiError";
      this.code = code || "unknown";
    }
  }

  async function request(path, params, opts) {
    opts = opts || {};
    const cacheKey = path + "?" + JSON.stringify(params || {});
    const now = Date.now();

    if (!opts.noCache) {
      const cached = memoryCache.get(cacheKey);
      if (cached && cached.expires > now) {
        return cached.data;
      }
    }

    if (!navigator.onLine) {
      throw new ApiError("You appear to be offline.", "offline");
    }

    const url = buildUrl(path, params);
    let response;
    try {
      response = await fetch(url, {
        method: "GET",
        headers: {
          Authorization: "Bearer " + CONFIG.API_TOKEN,
          Accept: "application/json",
        },
      });
    } catch (networkErr) {
      throw new ApiError(
        "Could not reach the ChessPairings API (network or CORS error).",
        "network"
      );
    }

    if (response.status === 401) {
      throw new ApiError("API token is invalid or missing.", "unauthorized");
    }
    if (response.status === 404) {
      throw new ApiError("Resource not found.", "not_found");
    }
    if (response.status === 429) {
      throw new ApiError("Rate limit exceeded. Please try again shortly.", "rate_limit");
    }
    if (!response.ok) {
      throw new ApiError("HTTP error " + response.status, "http_error");
    }

    let data;
    try {
      data = await response.json();
    } catch (e) {
      throw new ApiError("Invalid JSON response from server.", "invalid_json");
    }

    memoryCache.set(cacheKey, { data, expires: now + CONFIG.CACHE_TTL_MS });
    return data;
  }

  /**
   * Wraps a live request with an optional demo-data fallback so pages keep
   * working out of the box even before a real token/tournament is set up.
   */
  async function withFallback(livePromiseFactory, demoFactory) {
    try {
      return { data: await livePromiseFactory(), isDemo: false };
    } catch (err) {
      if (CONFIG.DEMO_MODE_FALLBACK && typeof demoFactory === "function") {
        console.warn("[ChessPairings] Falling back to demo data:", err.message);
        return { data: demoFactory(), isDemo: true, error: err };
      }
      throw err;
    }
  }

  const basePath = () =>
    CONFIG.TOURNAMENT_TYPE === "squadre" ? "torneo_squadre" : "torneo";

  const Api = {
    ApiError,

    async ping() {
      return request("me", {}, { noCache: true });
    },

    async getTournament() {
      return withFallback(
        () => request(`${basePath()}/${CONFIG.TOURNAMENT_ID}`),
        () => global.DemoData.tournament()
      );
    },

    async getStandings() {
      return withFallback(
        () => request(`${basePath()}/${CONFIG.TOURNAMENT_ID}/classifica`),
        () => global.DemoData.standings()
      );
    },

    async getRounds() {
      return withFallback(
        () => request(`${basePath()}/${CONFIG.TOURNAMENT_ID}/turni`),
        () => global.DemoData.rounds()
      );
    },

    async getPairings(round) {
      return withFallback(
        () =>
          request(`${basePath()}/${CONFIG.TOURNAMENT_ID}/abbinamenti`, {
            turno: round || "ultimo",
          }),
        () => global.DemoData.pairings(round)
      );
    },

    async getPlayers(sortKey) {
      return withFallback(
        () =>
          request(`${basePath()}/${CONFIG.TOURNAMENT_ID}/iscritti`, {
            ordinamento: sortKey || "rating",
          }),
        () => global.DemoData.players()
      );
    },

    async getAnnouncement() {
      return withFallback(
        () => request(`${basePath()}/${CONFIG.TOURNAMENT_ID}/bando`),
        () => global.DemoData.announcement()
      );
    },
  };

  global.Api = Api;
})(window);
