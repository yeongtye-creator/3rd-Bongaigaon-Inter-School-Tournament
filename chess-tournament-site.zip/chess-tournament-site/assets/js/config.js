/**
 * config.js
 * -----------------------------------------------------------------------
 * Central configuration for the site. This is the ONLY file that should
 * ever contain API credentials or tournament identifiers. Every other
 * script reads from window.CONFIG — never hardcode these values elsewhere.
 *
 * HOW TO EDIT:
 *   1. Replace API_TOKEN with your ChessPairings API bearer token.
 *   2. Replace TOURNAMENT_ID with the numeric ID of your tournament
 *      (visible in the ChessPairings dashboard / URL).
 *   3. Set TOURNAMENT_TYPE to "individuale" or "squadre" depending on
 *      whether this is an individual or team tournament.
 *
 * SECURITY NOTE:
 *   This is a static, client-side site, so anything placed here is
 *   visible to anyone who views the page source. Only use a token that
 *   is safe to expose publicly (a read-only / public-facing token), and
 *   confirm with ChessPairings that browser-side (CORS) requests are
 *   permitted for your account before relying on this in production.
 *   If your token must stay private, put a small proxy server between
 *   this site and the ChessPairings API instead of calling it directly.
 * -----------------------------------------------------------------------
 */
window.CONFIG = {
  // ---- API connection -----------------------------------------------
  API_BASE_URL: "https://my.chesspairings.org/api/v1",
  API_TOKEN: "YOUR_CHESSPAIRINGS_API_TOKEN",
  TOURNAMENT_ID: "12345",
  TOURNAMENT_TYPE: "individuale", // "individuale" | "squadre"

  // ---- Site identity ---------------------------------------------------
  SITE_NAME: "Bongaigaon Inter-School Chess Tournament",
  SITE_SHORT_NAME: "BISCT",
  ORGANIZER_NAME: "AdmirerX & Bongaigaon Chess Circle",
  ORGANIZER_EMAIL: "contact@example.com",
  ORGANIZER_PHONE: "+91 00000 00000",
  SITE_DESCRIPTION: "Live standings, pairings and player information for the tournament.",
  SITE_URL: "https://example.github.io/chess-tournament-site/",

  // ---- Behaviour -------------------------------------------------------
  REFRESH_INTERVAL_MS: 30000,     // auto-refresh cadence for live pages
  PAGE_SIZE: 20,                  // rows per page for tables/lists
  CACHE_TTL_MS: 20000,            // in-memory cache lifetime for API responses

  // ---- Demo mode ---------------------------------------------------------
  // When true, if a live API call fails (no token set, CORS blocked, or
  // network error), the site falls back to realistic sample data so every
  // page still renders correctly. Set to false once your API is live.
  DEMO_MODE_FALLBACK: true,
};
