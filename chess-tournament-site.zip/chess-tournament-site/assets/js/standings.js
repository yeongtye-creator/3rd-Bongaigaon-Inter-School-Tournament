/**
 * standings.js
 * -----------------------------------------------------------------------
 * Drives standings.html: fetches the classifica (standings) data, and
 * handles search, sorting, pagination and 30-second auto-refresh.
 * -----------------------------------------------------------------------
 */
(function () {
  "use strict";

  const state = {
    all: [],
    filtered: [],
    query: "",
    sortKey: "posizione",
    sortDir: "asc",
    page: 1,
    pageSize: (window.CONFIG && CONFIG.PAGE_SIZE) || 20,
  };

  const els = {};

  document.addEventListener("DOMContentLoaded", () => {
    els.tableWrap = document.getElementById("standings-table-wrap");
    els.tbody = document.getElementById("standings-tbody");
    els.title = document.getElementById("standings-title");
    els.search = document.getElementById("standings-search");
    els.pagination = document.getElementById("pagination");
    els.count = document.getElementById("standings-count");
    els.sortBtns = Utils.qsa("[data-sort]");
    els.demoBanner = document.getElementById("demo-banner");

    els.search.addEventListener(
      "input",
      Utils.debounce((e) => {
        state.query = e.target.value.trim().toLowerCase();
        state.page = 1;
        applyFilters();
      }, 180)
    );

    els.sortBtns.forEach((btn) =>
      btn.addEventListener("click", () => {
        const key = btn.dataset.sort;
        if (state.sortKey === key) {
          state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
        } else {
          state.sortKey = key;
          state.sortDir = key === "punti" ? "desc" : "asc";
        }
        updateSortButtons();
        applyFilters();
      })
    );

    load();
    const indicator = UI.refreshIndicator(CONFIG.REFRESH_INTERVAL_MS, load);
    indicator.start();
  });

  async function load() {
    showLoading();
    try {
      const [torneoRes, standingsRes] = await Promise.all([
        Api.getTournament(),
        Api.getStandings(),
      ]);
      if (els.title && torneoRes.data.nome) {
        els.title.textContent = torneoRes.data.nome;
      }
      toggleDemoBanner(torneoRes.isDemo || standingsRes.isDemo);
      state.all = standingsRes.data.items || [];
      applyFilters();
    } catch (err) {
      UI.errorState(els.tableWrap, err.message, load);
    }
  }

  function toggleDemoBanner(isDemo) {
    if (!els.demoBanner) return;
    els.demoBanner.style.display = isDemo ? "flex" : "none";
  }

  function showLoading() {
    els.tbody.innerHTML = UI.skeletonRows(8, 6);
  }

  function applyFilters() {
    let rows = state.all;
    if (state.query) {
      rows = rows.filter((r) => {
        const hay = `${r.cognome || ""} ${r.nome || ""} ${r.federazione || ""}`.toLowerCase();
        return hay.includes(state.query);
      });
    }
    rows = rows.slice().sort((a, b) => {
      const dir = state.sortDir === "asc" ? 1 : -1;
      const key = state.sortKey;
      if (key === "nome") {
        return dir * Utils.fullName(a).localeCompare(Utils.fullName(b));
      }
      const av = parseFloat(a[key]) || 0;
      const bv = parseFloat(b[key]) || 0;
      return dir * (av - bv);
    });
    state.filtered = rows;
    render();
  }

  function render() {
    if (!state.all.length) {
      UI.emptyState(els.tableWrap, "No standings published yet", "Check back once the first round has been paired and results entered.");
      els.pagination.innerHTML = "";
      els.count.textContent = "";
      return;
    }
    if (!state.filtered.length) {
      UI.emptyState(els.tableWrap, "No players match your search", "Try a different name or federation code.");
      els.pagination.innerHTML = "";
      els.count.textContent = "0 results";
      return;
    }
    ensureTableMarkup();
    const start = (state.page - 1) * state.pageSize;
    const pageRows = state.filtered.slice(start, start + state.pageSize);

    els.tbody.innerHTML = pageRows
      .map((r) => {
        const sp = r.spareggi && typeof r.spareggi === "object" ? Object.values(r.spareggi) : [];
        return `<tr>
          <td class="rank-cell">${Utils.escapeHtml(r.posizione ?? "-")}</td>
          <td>
            <div class="player-name-cell">
              ${r.titolo ? `<span class="title-tag">${Utils.escapeHtml(r.titolo)}</span>` : ""}
              <span>${Utils.escapeHtml(Utils.fullName(r))}</span>
            </div>
          </td>
          <td>${r.federazione ? `<span class="fed-tag">${Utils.escapeHtml(r.federazione)}</span>` : "—"}</td>
          <td class="mono">${Utils.escapeHtml(r.rating_iniziale ?? r.rating ?? "—")}</td>
          <td class="score-cell">${Utils.escapeHtml(r.punti ?? "0")}</td>
          <td class="mono">${sp.length ? sp.map((v) => Utils.escapeHtml(v)).join(" / ") : "—"}</td>
        </tr>`;
      })
      .join("");

    els.count.textContent = `${state.filtered.length} player${state.filtered.length === 1 ? "" : "s"}`;
    renderPagination();
  }

  function ensureTableMarkup() {
    if (Utils.qs("table", els.tableWrap)) return;
    els.tableWrap.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th data-sort="posizione">Rank</th>
            <th data-sort="nome">Player</th>
            <th>Federation</th>
            <th data-sort="rating">Rating</th>
            <th data-sort="punti">Score</th>
            <th>Tie-breaks</th>
          </tr>
        </thead>
        <tbody id="standings-tbody"></tbody>
      </table>`;
    els.tbody = document.getElementById("standings-tbody");
    Utils.qsa("th[data-sort]", els.tableWrap).forEach((th) =>
      th.addEventListener("click", () => {
        const key = th.dataset.sort;
        if (state.sortKey === key) {
          state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
        } else {
          state.sortKey = key;
          state.sortDir = key === "punti" || key === "rating" ? "desc" : "asc";
        }
        updateSortButtons();
        applyFilters();
      })
    );
  }

  function updateSortButtons() {
    els.sortBtns.forEach((b) => b.classList.toggle("is-active", b.dataset.sort === state.sortKey));
    Utils.qsa("th[data-sort]", els.tableWrap).forEach((th) =>
      th.classList.toggle("is-sorted", th.dataset.sort === state.sortKey)
    );
  }

  function renderPagination() {
    const totalPages = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
    if (state.page > totalPages) state.page = totalPages;
    let html = `<button class="page-btn" ${state.page === 1 ? "disabled" : ""} data-page="prev" aria-label="Previous page">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
    </button>`;
    for (let p = 1; p <= totalPages; p++) {
      if (totalPages > 7 && p !== 1 && p !== totalPages && Math.abs(p - state.page) > 1) {
        if (p === 2 || p === totalPages - 1) html += `<span class="page-btn" style="border:none;background:none">…</span>`;
        continue;
      }
      html += `<button class="page-btn ${p === state.page ? "is-active" : ""}" data-page="${p}">${p}</button>`;
    }
    html += `<button class="page-btn" ${state.page === totalPages ? "disabled" : ""} data-page="next" aria-label="Next page">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
    </button>`;
    els.pagination.innerHTML = html;
    Utils.qsa("[data-page]", els.pagination).forEach((btn) =>
      btn.addEventListener("click", () => {
        const val = btn.dataset.page;
        if (val === "prev") state.page = Math.max(1, state.page - 1);
        else if (val === "next") state.page = Math.min(totalPages, state.page + 1);
        else state.page = Number(val);
        render();
        els.tableWrap.scrollIntoView({ behavior: "smooth", block: "nearest" });
      })
    );
  }
})();
