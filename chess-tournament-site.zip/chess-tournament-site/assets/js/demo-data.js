/**
 * demo-data.js
 * -----------------------------------------------------------------------
 * Sample data used ONLY as a fallback when DEMO_MODE_FALLBACK is true and
 * a live API call fails (e.g. no token configured yet, or CORS blocked).
 * Shaped to match the real ChessPairings API v1 response fields exactly,
 * so switching to live data requires no changes elsewhere in the app.
 * -----------------------------------------------------------------------
 */
(function (global) {
  "use strict";

  const NAMES = [
    ["Rahman", "Aditya", "IN", 1842, "FM"],
    ["Bora", "Priyanka", "IN", 1795, ""],
    ["Deka", "Kaushik", "IN", 1760, ""],
    ["Sharma", "Ishaan", "IN", 1701, ""],
    ["Choudhury", "Meher", "IN", 1688, ""],
    ["Baruah", "Rohan", "IN", 1654, ""],
    ["Nath", "Ananya", "IN", 1612, ""],
    ["Das", "Sourav", "IN", 1598, ""],
    ["Kalita", "Priyam", "IN", 1560, ""],
    ["Islam", "Tanvir", "IN", 1522, ""],
    ["Goswami", "Riya", "IN", 1499, ""],
    ["Talukdar", "Arnab", "IN", 1470, ""],
    ["Hazarika", "Debojit", "IN", 1445, ""],
    ["Medhi", "Simran", "IN", 1420, ""],
    ["Saikia", "Nilakshi", "IN", 1388, ""],
    ["Pathak", "Yashodeep", "IN", 1355, ""],
    ["Ray", "Oindrila", "IN", 1330, ""],
    ["Barman", "Kabya", "IN", 1298, ""],
    ["Chetia", "Manas", "IN", 1260, ""],
    ["Roy", "Debashish", "IN", 1210, ""],
  ];

  function tournament() {
    return {
      nome: "3rd Bongaigaon Inter-School Chess Tournament (Demo)",
      luogo: "Bongaigaon, Assam, India",
      data_inizio: "2026-07-05",
      data_fine: "2026-07-05",
      tipo_torneo: "Swiss",
      num_turni: 7,
      turno_corrente: 4,
      cadenza: "Rapid — 15 min + 5 sec increment",
      visibilita: "pubblico",
      num_iscritti: NAMES.length,
      stato: "in_corso",
      token_pubblico: "",
      link_pubblico: "",
      descrizione:
        "This is sample data shown because no live tournament is connected yet. Configure assets/js/config.js with your API token and tournament ID to replace it with live results.",
    };
  }

  function standings() {
    const items = NAMES.map(([cognome, nome, federazione, rating, titolo], i) => {
      const punti = Math.max(0.5, 3.5 - i * 0.18 + (i % 3 === 0 ? 0.3 : 0)).toFixed(1);
      return {
        posizione: i + 1,
        titolo,
        cognome,
        nome,
        federazione,
        rating,
        punti,
        stato: "attivo",
        spareggi: { bucch: (10 - i * 0.4).toFixed(1), sb: (8 - i * 0.3).toFixed(1) },
      };
    });
    return { items };
  }

  function rounds() {
    const items = [];
    for (let i = 1; i <= 4; i++) items.push({ turno: i });
    return { items };
  }

  function pairings(round) {
    const r = round && round !== "ultimo" && round !== "corrente" ? Number(round) : 4;
    const items = [];
    for (let i = 0; i < NAMES.length; i += 2) {
      const w = NAMES[i];
      const b = NAMES[i + 1];
      const board = i / 2 + 1;
      const results = ["1-0", "0-1", "1/2-1/2", null];
      items.push({
        tavolo: board,
        bianco: { cognome: w[0], nome: w[1], titolo: w[4], rating: w[3], punti_pre: (3 - board * 0.1).toFixed(1) },
        nero: b
          ? { cognome: b[0], nome: b[1], titolo: b[4], rating: b[3], punti_pre: (3 - board * 0.12).toFixed(1) }
          : null,
        tipo: b ? "normale" : "bye",
        risultato: b ? results[board % results.length] : "+",
      });
    }
    return { items, turno: r };
  }

  function players() {
    const items = NAMES.map(([cognome, nome, federazione, rating, titolo], i) => ({
      num_tavolo: i + 1,
      titolo,
      cognome,
      nome,
      federazione,
      sesso: i % 3 === 0 ? "F" : "M",
      anno_nascita: 2008 + (i % 9),
      rating,
      categoria: rating >= 1600 ? "Queen" : rating >= 1400 ? "Knight" : "Pawn",
      stato: "attivo",
    }));
    return { items };
  }

  function announcement() {
    return {
      titolo: "Round 5 pairings will be posted shortly",
      testo:
        "Sample announcement: this text is placeholder content shown in demo mode. Replace it with your live /bando data once the API is connected.",
      data: new Date().toISOString(),
    };
  }

  global.DemoData = { tournament, standings, rounds, pairings, players, announcement };
})(window);
