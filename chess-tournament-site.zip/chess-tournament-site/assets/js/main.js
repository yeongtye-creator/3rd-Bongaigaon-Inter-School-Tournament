/**
 * main.js
 * -----------------------------------------------------------------------
 * Shared behaviour loaded on every page: navigation, dark mode, back-to-
 * top, floating refresh indicator, keyboard shortcuts, toasts, and a
 * small Utils/UI helper library used by standings.js / pairings.js /
 * players.js so those files can stay focused on their own page logic.
 * -----------------------------------------------------------------------
 */
(function (global) {
  "use strict";

  /* ============================= Utils ================================ */
  const Utils = {
    escapeHtml(str) {
      if (str === null || str === undefined) return "";
      return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    },

    debounce(fn, wait) {
      let t;
      return function (...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
      };
    },

    fullName(row) {
      const cognome = row.cognome || "";
      const nome = row.nome || "";
      return `${cognome} ${nome}`.trim() || "Unnamed player";
    },

    initials(row) {
      const c = (row.cognome || "?").trim()[0] || "?";
      const n = (row.nome || "").trim()[0] || "";
      return (c + n).toUpperCase();
    },

    formatDate(iso) {
      if (!iso) return "";
      const d = new Date(iso);
      if (isNaN(d)) return iso;
      return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    },

    formatDateRange(start, end) {
      const s = Utils.formatDate(start);
      const e = Utils.formatDate(end);
      if (s && e && s !== e) return `${s} – ${e}`;
      return s || e || "TBA";
    },

    resultLabel(r) {
      const map = { "1-0": "1–0", "0-1": "0–1", "1/2-1/2": "½–½", "+": "+", "-": "–" };
      if (r === null || r === undefined || r === "") return "—";
      return map[r] || r;
    },

    statusLabel(stato) {
      const map = {
        iscrizioni: "Registration open",
        in_corso: "In progress",
        concluso: "Completed",
      };
      return map[stato] || stato || "";
    },

    qs(sel, root) {
      return (root || document).querySelector(sel);
    },
    qsa(sel, root) {
      return Array.from((root || document).querySelectorAll(sel));
    },
  };
  global.Utils = Utils;

  /* ============================== UI =================================== */
  const UI = {
    skeletonRows(n, cols) {
      let html = "";
      for (let i = 0; i < n; i++) {
        html += `<tr>${Array.from({ length: cols })
          .map(() => `<td><div class="skeleton skeleton-row"></div></td>`)
          .join("")}</tr>`;
      }
      return html;
    },

    skeletonCards(n) {
      let html = "";
      for (let i = 0; i < n; i++) html += `<div class="skeleton skeleton-card"></div>`;
      return html;
    },

    errorState(container, message, onRetry) {
      container.innerHTML = `
        <div class="state-block fade-in">
          <svg class="state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><circle cx="12" cy="16" r=".6" fill="currentColor" stroke="none"/>
          </svg>
          <h3 class="state-title">Couldn't load this data</h3>
          <p class="state-desc">${Utils.escapeHtml(message || "Something went wrong while contacting the tournament server.")}</p>
          <button class="btn btn-primary retry-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 4v6h-6"/></svg>
            Retry
          </button>
        </div>`;
      const btn = container.querySelector(".retry-btn");
      if (btn && onRetry) btn.addEventListener("click", onRetry);
    },

    emptyState(container, title, desc) {
      container.innerHTML = `
        <div class="state-block fade-in">
          <svg class="state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/><path d="M9 4v16"/>
          </svg>
          <h3 class="state-title">${Utils.escapeHtml(title)}</h3>
          <p class="state-desc">${Utils.escapeHtml(desc || "")}</p>
        </div>`;
    },

    toast(message) {
      let el = document.getElementById("global-toast");
      if (!el) {
        el = document.createElement("div");
        el.id = "global-toast";
        el.className = "toast";
        document.body.appendChild(el);
      }
      el.textContent = message;
      el.classList.add("is-visible");
      clearTimeout(el._t);
      el._t = setTimeout(() => el.classList.remove("is-visible"), 2600);
    },

    /**
     * Wires up a floating "last updated / next refresh" indicator plus a
     * manual refresh button. Returns { start(), stop(), refreshNow() }.
     */
    refreshIndicator(intervalMs, onRefresh) {
      const el = document.getElementById("refresh-indicator");
      if (!el) return { start() {}, stop() {}, refreshNow() { return onRefresh(); } };
      const ring = el.querySelector("circle");
      const label = el.querySelector(".refresh-label");
      const btn = el.querySelector(".refresh-now-btn");
      const circumference = 44;
      let remaining = intervalMs;
      let timer = null;
      let tickTimer = null;

      function paint() {
        const frac = remaining / intervalMs;
        ring.style.strokeDashoffset = String(circumference * (1 - frac));
        label.textContent = `Updated · next in ${Math.ceil(remaining / 1000)}s`;
      }

      async function doRefresh(manual) {
        remaining = intervalMs;
        paint();
        try {
          await onRefresh();
          label.textContent = manual ? "Refreshed just now" : "Updated · next in " + Math.ceil(intervalMs / 1000) + "s";
          setTimeout(paint, 1200);
        } catch (e) {
          /* individual page handles its own error UI */
        }
      }

      function start() {
        el.classList.add("is-visible");
        paint();
        clearInterval(tickTimer);
        tickTimer = setInterval(() => {
          remaining -= 1000;
          if (remaining <= 0) {
            doRefresh(false);
          } else {
            paint();
          }
        }, 1000);
      }
      function stop() {
        clearInterval(tickTimer);
        el.classList.remove("is-visible");
      }
      if (btn) btn.addEventListener("click", () => doRefresh(true));

      return { start, stop, refreshNow: () => doRefresh(true) };
    },
  };
  global.UI = UI;

  /* =========================== Page chrome ============================= */
  document.addEventListener("DOMContentLoaded", () => {
    initNav();
    initDarkMode();
    initBackToTop();
    initKeyboardShortcuts();
    initOfflineBanner();
    injectFloatingChrome();
    markActiveNavLink();
    const yearEl = document.getElementById("footer-year");
    if (yearEl) yearEl.textContent = new Date().getFullYear();
    if (global.CONFIG) {
      Utils.qsa("[data-site-name]").forEach((n) => (n.textContent = CONFIG.SITE_NAME));
    }
  });

  function initNav() {
    const nav = document.querySelector(".site-nav");
    const toggle = document.querySelector(".nav-toggle");
    const links = document.querySelector(".nav-links");
    if (toggle && links) {
      toggle.addEventListener("click", () => {
        const open = links.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
      });
      Utils.qsa("a", links).forEach((a) =>
        a.addEventListener("click", () => links.classList.remove("is-open"))
      );
    }
    if (nav) {
      const onScroll = () => nav.classList.toggle("is-scrolled", window.scrollY > 6);
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }
  }

  function markActiveNavLink() {
    const path = location.pathname.split("/").pop() || "index.html";
    Utils.qsa(".nav-links a").forEach((a) => {
      const href = a.getAttribute("href");
      if (href === path || (path === "" && href === "index.html")) {
        a.classList.add("is-active");
      }
    });
  }

  function initDarkMode() {
    const stored = localStorage.getItem("cp-theme");
    const prefersDark = global.matchMedia && global.matchMedia("(prefers-color-scheme: dark)").matches;
    const theme = stored || (prefersDark ? "dark" : "light");
    applyTheme(theme);

    Utils.qsa(".dark-toggle").forEach((btn) => {
      btn.addEventListener("click", () => {
        const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
        applyTheme(next);
        localStorage.setItem("cp-theme", next);
      });
    });
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    Utils.qsa(".dark-toggle .icon-sun").forEach((i) => (i.style.display = theme === "dark" ? "block" : "none"));
    Utils.qsa(".dark-toggle .icon-moon").forEach((i) => (i.style.display = theme === "dark" ? "none" : "block"));
  }

  function initBackToTop() {
    const btn = document.getElementById("back-to-top");
    if (!btn) return;
    window.addEventListener(
      "scroll",
      () => btn.classList.toggle("is-visible", window.scrollY > 480),
      { passive: true }
    );
    btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  function initOfflineBanner() {
    const banner = document.getElementById("offline-banner");
    if (!banner) return;
    const sync = () => banner.classList.toggle("is-visible", !navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
  }

  function injectFloatingChrome() {
    // Ensure back-to-top + refresh indicator markup exists even if a page
    // forgot to include it, so main.js behaviour always has a target.
    if (!document.getElementById("back-to-top")) {
      const btn = document.createElement("button");
      btn.id = "back-to-top";
      btn.className = "fab";
      btn.setAttribute("aria-label", "Back to top");
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></svg>`;
      const stack = document.querySelector(".float-stack") || (() => {
        const s = document.createElement("div");
        s.className = "float-stack";
        document.body.appendChild(s);
        return s;
      })();
      stack.appendChild(btn);
      initBackToTop();
    }
  }

  function initKeyboardShortcuts() {
    const popover = document.getElementById("kbd-popover");
    const searchInput = () => document.querySelector(".search-box input");

    document.addEventListener("keydown", (e) => {
      const tag = (e.target.tagName || "").toLowerCase();
      const typing = tag === "input" || tag === "textarea" || e.target.isContentEditable;

      if (e.key === "?" ) {
        e.preventDefault();
        if (popover) popover.classList.toggle("is-open");
        return;
      }
      if (e.key === "Escape" && popover) {
        popover.classList.remove("is-open");
        document.querySelectorAll(".modal-overlay.is-open").forEach((m) => m.classList.remove("is-open"));
        return;
      }
      if (typing) return;

      if (e.key === "/") {
        const input = searchInput();
        if (input) {
          e.preventDefault();
          input.focus();
        }
      } else if (e.key.toLowerCase() === "d") {
        document.querySelector(".dark-toggle")?.click();
      } else if (e.key.toLowerCase() === "r") {
        document.getElementById("refresh-indicator")?.querySelector(".refresh-now-btn")?.click();
      } else if (["1", "2", "3", "4", "5"].includes(e.key)) {
        const pages = ["index.html", "standings.html", "pairings.html", "players.html", "about.html"];
        location.href = pages[Number(e.key) - 1];
      }
    });

    if (popover) {
      popover.addEventListener("click", (e) => {
        if (e.target === popover) popover.classList.remove("is-open");
      });
      document.querySelectorAll("[data-open-shortcuts]").forEach((b) =>
        b.addEventListener("click", () => popover.classList.add("is-open"))
      );
      document.querySelectorAll("[data-close-shortcuts]").forEach((b) =>
        b.addEventListener("click", () => popover.classList.remove("is-open"))
      );
    }
  }
})(window);
