/**
 * players.js
 * -----------------------------------------------------------------------
 * Drives players.html: fetches the enrolled players list, supports
 * search, sorting, federation filtering, pagination, and a profile
 * popup modal for each player.
 * -----------------------------------------------------------------------
 */
(function () {
  "use strict";

  const state = {
    all: [],
    filtered: [],
    query: "",
    sortKey: "rating",
    sortDir: "desc",
    fedFilter: "all",
    page: 1,
    pageSize: (window.CONFIG && CONFIG.PAGE_SIZE) || 20,
  };
  const els = {};

  document.addEventListener("DOMContentLoaded", () => {
    els.grid = document.getElementById("players-grid");
    els.title = document.getElementById("players-title");
    els.search = document.getElementById("players-search");
    els.count = document.getElementById("players-count");
    els.sortSelect = document.getElementById("players-sort");
    els.fedSelect = document.getElementById("players-fed-filter");
    els.pagination = document.getElementById("pagination");
    els.demoBanner = document.getElementById("demo-banner");
    els.modalOverlay = document.getElementById("player-modal-overlay");
    els.modalBody = document.getElementById("player-modal-body");

    els.search.addEventListener(
      "input",
      Utils.debounce((e) => {
        state.query = e.target.value.trim().toLowerCase();
        state.page = 1;
        applyFilters();
      }, 180)
    );
    els.sortSelect.addEventListener("change", (e) => {
      const [key, dir] = e.target.value.split(":");
      state.sortKey = key;
      state.sortDir = dir;
      applyFilters();
    });
    els.fedSelect.addEventListener("change", (e) => {
      state.fedFilter = e.target.value;
      state.page = 1;
      applyFilters();
    });

    document.querySelectorAll("[data-close-modal]").forEach((b) =>
      b.addEventListener("click", closeModal)
    );
    els.modalOverlay.addEventListener("click", (e) => {
      if (e.target === els.modalOverlay) closeModal();
    });

    load();
  });

  async function load() {
    els.grid.innerHTML = UI.skeletonCards(9);
    try {
      const [torneoRes, playersRes] = await Promise.all([Api.getTournament(), Api.getPlayers()]);
      if (els.title && torneoRes.data.nome) els.title.textContent = torneoRes.data.nome;
      if (els.demoBanner) els.demoBanner.style.display = torneoRes.isDemo || playersRes.isDemo ? "flex" : "none";
      state.all = playersRes.data.items || [];
      populateFederations();
      applyFilters();
    } catch (err) {
      UI.errorState(els.grid, err.message, load);
    }
  }

  function populateFederations() {
    const feds = Array.from(new Set(state.all.map((p) => p.federazione).filter(Boolean))).sort();
    els.fedSelect.innerHTML =
      `<option value="all">All federations</option>` +
      feds.map((f) => `<option value="${Utils.escapeHtml(f)}">${Utils.escapeHtml(f)}</option>`).join("");
  }

  function applyFilters() {
    let rows = state.all;
    if (state.fedFilter !== "all") {
      rows = rows.filter((p) => p.federazione === state.fedFilter);
    }
    if (state.query) {
      rows = rows.filter((p) => {
        const hay = `${p.cognome || ""} ${p.nome || ""} ${p.federazione || ""} ${p.categoria || ""}`.toLowerCase();
        return hay.includes(state.query);
      });
    }
    rows = rows.slice().sort((a, b) => {
      const dir = state.sortDir === "asc" ? 1 : -1;
      if (state.sortKey === "nome") return dir * Utils.fullName(a).localeCompare(Utils.fullName(b));
      return dir * ((parseFloat(a[state.sortKey]) || 0) - (parseFloat(b[state.sortKey]) || 0));
    });
    state.filtered = rows;
    render();
  }

  function render() {
    if (!state.all.length) {
      UI.emptyState(els.grid, "No players enrolled yet", "The player list will appear here once registrations open.");
      els.pagination.innerHTML = "";
      els.count.textContent = "";
      return;
    }
    if (!state.filtered.length) {
      UI.emptyState(els.grid, "No players match", "Try a different name, federation or category.");
      els.pagination.innerHTML = "";
      els.count.textContent = "0 results";
      return;
    }
    const start = (state.page - 1) * state.pageSize;
    const pageRows = state.filtered.slice(start, start + state.pageSize);
    els.grid.innerHTML = pageRows.map(cardHtml).join("");
    els.count.textContent = `${state.filtered.length} player${state.filtered.length === 1 ? "" : "s"}`;
    Utils.qsa(".player-card", els.grid).forEach((card) =>
      card.addEventListener("click", () => openModal(state.filtered[start + Number(card.dataset.idx)]))
    );
    renderPagination();
  }

  function cardHtml(p, i) {
    return `
      <div class="player-card fade-in" data-idx="${i}" tabindex="0" role="button" aria-label="View profile for ${Utils.escapeHtml(Utils.fullName(p))}">
        <div class="player-avatar">${Utils.escapeHtml(Utils.initials(p))}</div>
        <div class="player-card-body">
          <div class="player-card-name">${p.titolo ? `<span class="title-tag">${Utils.escapeHtml(p.titolo)}</span> ` : ""}${Utils.escapeHtml(Utils.fullName(p))}</div>
          <div class="player-card-meta">
            ${p.federazione ? `<span class="fed-tag">${Utils.escapeHtml(p.federazione)}</span>` : ""}
            <span class="mono" style="font-size:.8rem;color:var(--text-muted)">Rtg ${Utils.escapeHtml(p.rating ?? "—")}</span>
            ${p.categoria ? `<span class="mono" style="font-size:.8rem;color:var(--text-muted)">${Utils.escapeHtml(p.categoria)}</span>` : ""}
          </div>
        </div>
      </div>`;
  }

  function openModal(p) {
    if (!p) return;
    els.modalBody.innerHTML = `
      <div class="modal-header">
        <div class="modal-avatar">${Utils.escapeHtml(Utils.initials(p))}</div>
        <div>
          <div class="modal-title">${p.titolo ? `<span class="title-tag">${Utils.escapeHtml(p.titolo)}</span> ` : ""}${Utils.escapeHtml(Utils.fullName(p))}</div>
          <div class="modal-subtitle">${Utils.escapeHtml(p.federazione || "Federation N/A")} ${p.categoria ? "· " + Utils.escapeHtml(p.categoria) : ""}</div>
        </div>
      </div>
      <div class="modal-grid">
        <div class="modal-stat"><div class="modal-stat-label">Rating</div><div class="modal-stat-value">${Utils.escapeHtml(p.rating ?? "—")}</div></div>
        <div class="modal-stat"><div class="modal-stat-label">Board / Seed</div><div class="modal-stat-value">${Utils.escapeHtml(p.num_tavolo ?? "—")}</div></div>
        <div class="modal-stat"><div class="modal-stat-label">Birth year</div><div class="modal-stat-value">${Utils.escapeHtml(p.anno_nascita ?? "—")}</div></div>
        <div class="modal-stat"><div class="modal-stat-label">Gender</div><div class="modal-stat-value">${Utils.escapeHtml(p.sesso ?? "—")}</div></div>
      </div>`;
    els.modalOverlay.classList.add("is-open");
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    els.modalOverlay.classList.remove("is-open");
    document.body.style.overflow = "";
  }

  function renderPagination() {
    const totalPages = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
    if (state.page > totalPages) state.page = totalPages;
    let html = `<button class="page-btn" ${state.page === 1 ? "disabled" : ""} data-page="prev" aria-label="Previous page">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
    </button>`;
    for (let p = 1; p <= totalPages; p++) {
      if (totalPages > 7 && p !== 1 && p !== totalPages && Math.abs(p - state.page) > 1) {
        if (p === 2 || p === totalPages - 1) html += `<span class="page-btn" style="border:none;background:none">…</span>`;
        continue;
      }
      html += `<button class="page-btn ${p === state.page ? "is-active" : ""}" data-page="${p}">${p}</button>`;
    }
    html += `<button class="page-btn" ${state.page === totalPages ? "disabled" : ""} data-page="next" aria-label="Next page">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
    </button>`;
    els.pagination.innerHTML = html;
    Utils.qsa("[data-page]", els.pagination).forEach((btn) =>
      btn.addEventListener("click", () => {
        const val = btn.dataset.page;
        if (val === "prev") state.page = Math.max(1, state.page - 1);
        else if (val === "next") state.page = Math.min(totalPages, state.page + 1);
        else state.page = Number(val);
        render();
        els.grid.scrollIntoView({ behavior: "smooth", block: "nearest" });
      })
    );
  }
})();
